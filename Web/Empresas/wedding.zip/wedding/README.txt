
TITLE: 
Wedding Free HTML5 Bootstrap Template for Wedding Website
AUTHOR:
DESIGNED & DEVELOPED by QBOOTSTRAP.COM

Website: 		http://qbootstrap.com/
Twitter: 		http://twitter.com/Q_bootstrap
Facebook: 		https://www.facebook.com/Qbootstrap

CREDITS:

Bootstrap
http://getbootstrap.com/

jQuery
http://jquery.com/

jQuery Easing
http://gsgd.co.uk/sandbox/jquery/easing/

Modernizr
http://modernizr.com/

Google Fonts
https://www.google.com/fonts/

Icomoon
https://icomoon.io/app/

Simple Line Icons
https://github.com/thesabbir/simple-line-icons

Flaticon Icons
https://www.flaticon.com/

Respond JS
https://github.com/scottjehl/Respond/blob/master/LICENSE-MIT

animate.css
http://daneden.me/animate

jQuery Waypoint
https://github.com/imakewebthings/waypoints/blog/master/licenses.txt

Owl Carousel
http://www.owlcarousel.owlgraphic.com/

Stellar JS
http://markdalgleish.com/projects/stellar.js/

Magnific Popup
http://dimsemenov.com/plugins/magnific-popup/

YTPlayer Video Background JS
http://pupunzi.open-lab.com

Flex Slider
http://www.woothemes.com/flexslider/
