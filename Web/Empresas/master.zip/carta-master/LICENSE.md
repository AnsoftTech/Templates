# License

You may:
- Use this site template for personal stuff.
- Use this site template for commercial stuff.
- Change this site template however you like.

You may not:
- Sell this site template, or a modification of it, by itself or in a package with other items.
- Distribute this site template to others. Just point them to eatapapaya.com.

You do not have to:
- Give attribution to Papaya or Jordan Bowman, although it is appreciated. :)
